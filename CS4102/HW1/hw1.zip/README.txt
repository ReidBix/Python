Reid Bixler
rmb3yz
CS 4102 hw1.py
1/23/2015

I completed the required homework 1 programming assignment through Python 3.4.0.
I ran the following into my console/terminal:
	./python hw1.py file.txt
to obtain the following output:
	$0.63 Q Q D P P P
	$1.06 N P
	$3.25 Q
	$1,000.06 N P
	$3.00
assuming the given input file:
	0.63
	1.06
	3.25
	1000.06
	3.00
	-1.00

This is my first time ever programming in Python, but I hope/believe that I have worked out most of the basic stuff that I already know in C++/Java.
It may not be as succinct as possible, but it does get the job done reasonably given that this is my first time working with this language.
Attached in the hw1.zip should be:
	hw1.py
	README.txt
and I have assumed that you all will provide the text files.