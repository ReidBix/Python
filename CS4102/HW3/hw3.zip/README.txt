Reid Bixler
rmb3yz
CS 4102 hw3.py
2/20/2015

I completed the required homework 3 programming assignment through Python 3.4.0.
I ran the following into my console/terminal:
	./python hw3.py file.txt
to obtain the following output:
	4.6265
    infinity
    5.7530
    4.4838
    3.2257
assuming the given input file:
    2
    1.25 6.11
    1.64 1.50
    2
    0 0
    0 10001
    3
    -6.47 2.24
    8.90 6.53
    -1.45 5.05
    4
    2.77 -9.81
    -0.19 4.85
    1.38 9.05
    -4.95 3.93
    10
    8.15 6.21
    -5.64 -4.31
    -0.03 7.05
    5.98 -4.64
    1.49 -1.59
    4.34 0.67
    -2.79 -0.93
    -7.41 2.89
    -1.79 -6.22
    -0.98 1.740
    0

This is my third time ever programming in Python, and I feel pretty comfortable with it as of now.
This was the first time I created alternate functions outside of the main one in Python, which wasn't too difficult.
I like the way that Python is so easily programmable in that there is little to no unecessary coding like there can
be in Java. You can simple say what you want in as characters as possible but still being able to understand
and explain what is going on.
Hopefully my code should be relatively n*log(n) time, I did check it to the 10,000 points as well as
having executed the divide and conquer technique, so it should be relatively around the acceptable time,
but I do understand that Python can be a slower running program because of all of the work it does behind
the scenes as well as my use of lists and tuples.
Attached in the hw3.zip should be:
	hw3.py
	README.txt
and I have assumed that you all will provide the text files.