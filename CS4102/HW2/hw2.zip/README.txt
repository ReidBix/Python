Reid Bixler
rmb3yz
CS 4102 hw2.py
1/30/2015

I completed the required homework 2 programming assignment through Python 3.4.0.
I ran the following into my console/terminal:
	./python hw2.py file.txt
to obtain the following output:
	Case 1
    UHAUL 12
    USPS 28
    COURIER 30
    FEDEX 34
    DHL 46
    UPS 90
    Case 2
    UNITED 0
    DELTA 2
    USAIR 2
    SOUTHWEST 20
    AMERICAN 100
assuming the given input file:
    2
    75 10 6
    DHL 5 3
    UPS 9 9
    USPS 3 2
    FEDEX 3 5
    COURIER 2 7
    UHAUL 1 2
    2246 2245 5
    AMERICAN 100 600
    USAIR 2 2000
    SOUTHWEST 20 20
    DELTA 2 100
    UNITED 0 0

This is my second time ever programming in Python, and I feel as though I have gotten a better grasp on the language.
Once again, I realize that some of my coding may be essentially coding like Java in Python, but I am taking steps to
understand the language better and hopefully I will become more versatile in it.
Attached in the hw2.zip should be:
	hw2.py
	README.txt
and I have assumed that you all will provide the text files.