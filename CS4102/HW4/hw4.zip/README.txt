Reid Bixler
rmb3yz
CS 4102 hw4.py
3/6/2015

I completed the required homework 4 programming assignment through Python 3.4.0.
I ran the following into my console/terminal:
	./python hw4.py file.txt
to obtain the following output:
	Charlottesville: 7
    Richmond: 1
    WashingtonDC: 5
Wintergreen: 25
assuming the given input file:
    4
    Charlottesville 5 5
    66 78 41 3 77
    4 90 41 8 68
    12 11 29 24 53
    0 51 58 9 28
    97 99 96 58 92
    Richmond 3 3
    1 1 1
    1 1 1
    1 1 1
    WashingtonDC 5 5
    10 81 28 2 49
    64 59 61 85 82
    77 14 81 6 76
    37 86 99 11 92
    85 95 78 13 57
    Wintergreen 5 5
    1 2 3 4 5
    10 9 8 7 6
    11 12 13 14 15
    20 19 18 17 16
    21 22 23 24 25

This is my fourth time programming in Python, and feel as though I've learned a majority of the necessary details.
This was the second time I created alternate functions outside of the main one in Python, which wasn't too difficult
having had previous experience from hw3. Python is really beginning to grow on me and I can see why it can be deemed
a 'necessary' language to learn.
My code was implemented through the memoization for of dynamic programming, and hopefully it should be
the better choice. I thought that it was because it made sense to simply remember the distances for previously obtained
parts on the grid, much in the same as remembering the previously calculated numbers in the Fibonacci sequence.
Attached in the hw4.zip should be:
	hw4.py
	README.txt
and I have assumed that you all will provide the text files.